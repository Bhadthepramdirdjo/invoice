/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.php",
    "./page/**/*.php",
    "./pages/**/*.php",
    "./api/**/*.php",
    "./js/**/*.js",
    "./**/*.html"
  ],
  theme: {
    extend: {
      colors: {
        // Custom colors untuk invoice app
        'invoice-primary': '#3B82F6',
        'invoice-secondary': '#8B5CF6',
        'invoice-success': '#10B981',
        'invoice-warning': '#F59E0B',
        'invoice-danger': '#EF4444',
        'invoice-dark': '#1F2937',
        'invoice-light': '#F9FAFB',
      },
      fontFamily: {
        'sans': ['Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        'invoice': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        'invoice-lg': '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-in-out',
        'slide-in': 'slideIn 0.3s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideIn: {
          '0%': { transform: 'translateY(-10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      },
    },
  },
  plugins: [],
}
