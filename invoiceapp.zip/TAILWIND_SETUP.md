# 🎨 TailwindCSS Setup - Invoice App

Dokumentasi lengkap untuk setup dan penggunaan TailwindCSS Standalone CLI di Invoice App.

---

## 📁 File Structure

```
invoiceapp/
├── tailwindcss.exe          # TailwindCSS Standalone executable
├── tailwind.config.js       # Konfigurasi TailwindCSS
├── input.css                # Source CSS dengan @tailwind directives
├── build.ps1                # Script untuk build production
├── watch.ps1                # Script untuk development (auto-rebuild)
├── css/
│   └── output.css          # Generated CSS (hasil build)
├── index.php
├── page/
└── ...
```

---

## 🚀 Quick Start

### 1. Download TailwindCSS Executable (Sudah Dilakukan)

File `tailwindcss.exe` sudah di-download otomatis.

### 2. Build CSS Pertama Kali

```powershell
# Jalankan build script
.\build.ps1
```

Ini akan generate file `css/output.css` yang siap dipakai.

### 3. Link CSS di File PHP

Tambahkan di `<head>` setiap file PHP:

```html
<link href="css/output.css" rel="stylesheet">
```

---

## 🛠️ Development Workflow

### Mode 1: Watch Mode (Recommended untuk Development)

Jalankan watch mode agar CSS auto-rebuild saat ada perubahan:

```powershell
.\watch.ps1
```

**Cara kerja:**
1. Script akan terus berjalan dan watch perubahan
2. Setiap kali Anda edit file PHP/HTML dengan class Tailwind baru
3. CSS akan auto-rebuild dalam hitungan detik
4. Refresh browser untuk lihat perubahan
5. Tekan `Ctrl+C` untuk stop

### Mode 2: Manual Build

Jika tidak mau pakai watch mode, build manual setiap kali ada perubahan:

```powershell
.\build.ps1
```

---

## 🎨 Cara Menggunakan TailwindCSS

### Contoh 1: Button

```html
<!-- Button Primary -->
<button class="btn btn-primary">
    Simpan
</button>

<!-- Button Danger -->
<button class="btn btn-danger">
    Hapus
</button>

<!-- Button Outline -->
<button class="btn btn-outline">
    Batal
</button>
```

### Contoh 2: Card

```html
<div class="card">
    <div class="card-header">
        Daftar Produk
    </div>
    <p>Konten card di sini...</p>
</div>
```

### Contoh 3: Form

```html
<div class="form-group">
    <label class="form-label">Nama Produk</label>
    <input type="text" class="form-input" placeholder="Masukkan nama produk">
</div>

<div class="form-group">
    <label class="form-label">Kategori</label>
    <select class="form-select">
        <option>Pilih kategori</option>
        <option>Elektronik</option>
        <option>Makanan</option>
    </select>
</div>
```

### Contoh 4: Table

```html
<table class="table">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1</td>
            <td>Laptop</td>
            <td>Rp 5.000.000</td>
            <td>
                <button class="btn btn-primary">Edit</button>
            </td>
        </tr>
    </tbody>
</table>
```

### Contoh 5: Badge

```html
<span class="badge badge-success">Lunas</span>
<span class="badge badge-warning">Pending</span>
<span class="badge badge-danger">Belum Bayar</span>
```

### Contoh 6: Alert

```html
<div class="alert alert-success">
    Data berhasil disimpan!
</div>

<div class="alert alert-danger">
    Terjadi kesalahan, silakan coba lagi.
</div>
```

---

## 🎨 Custom Colors

Aplikasi ini sudah dilengkapi dengan custom colors:

```css
invoice-primary    → #3B82F6 (Biru)
invoice-secondary  → #8B5CF6 (Ungu)
invoice-success    → #10B981 (Hijau)
invoice-warning    → #F59E0B (Kuning)
invoice-danger     → #EF4444 (Merah)
invoice-dark       → #1F2937 (Hitam)
invoice-light      → #F9FAFB (Abu-abu terang)
```

**Cara pakai:**

```html
<div class="bg-invoice-primary text-white p-4">
    Background biru dengan text putih
</div>

<h1 class="text-invoice-secondary">
    Judul dengan warna ungu
</h1>
```

---

## 🎨 Utility Classes Tambahan

### Text Gradient

```html
<h1 class="text-gradient text-4xl font-bold">
    Judul dengan Gradient
</h1>
```

### Glass Effect

```html
<div class="glass-effect p-6 rounded-xl">
    Card dengan efek glassmorphism
</div>
```

### Shadow Glow

```html
<button class="btn btn-primary shadow-glow">
    Button dengan glow effect
</button>
```

---

## 📦 Deploy ke Hosting (InfinityFree)

### File yang Perlu Di-Upload:

```
✅ Upload:
├── index.php
├── css/
│   └── output.css          ← File hasil build (PENTING!)
├── js/
├── page/
├── api/
└── database/

❌ JANGAN Upload:
├── tailwindcss.exe         ← Tidak perlu
├── input.css               ← Tidak perlu
├── tailwind.config.js      ← Tidak perlu
├── build.ps1               ← Tidak perlu
├── watch.ps1               ← Tidak perlu
└── TAILWIND_SETUP.md       ← Tidak perlu
```

### Langkah Deploy:

1. **Build Production CSS:**
   ```powershell
   .\build.ps1
   ```

2. **Cek file `css/output.css` sudah ter-generate**

3. **Upload semua file KECUALI file yang ada di list ❌ di atas**

4. **Pastikan semua file PHP sudah link ke `css/output.css`**

5. **Test di hosting!**

---

## 🔧 Troubleshooting

### CSS tidak berubah setelah edit

**Solusi:**
1. Pastikan watch mode sedang berjalan (`.\watch.ps1`)
2. Atau jalankan build manual (`.\build.ps1`)
3. Hard refresh browser (`Ctrl + F5`)

### Class Tailwind tidak muncul

**Solusi:**
1. Cek apakah file sudah di-include di `tailwind.config.js` → `content`
2. Rebuild CSS: `.\build.ps1`
3. Cek apakah `css/output.css` sudah di-link di `<head>`

### File output.css terlalu besar

**Solusi:**
- Gunakan `.\build.ps1` yang sudah include `--minify`
- File akan otomatis di-compress

### Watch mode tidak auto-rebuild

**Solusi:**
1. Stop watch mode (`Ctrl + C`)
2. Jalankan ulang: `.\watch.ps1`

---

## 📚 Resources

- **TailwindCSS Docs:** https://tailwindcss.com/docs
- **Tailwind Cheat Sheet:** https://nerdcave.com/tailwind-cheat-sheet
- **Color Palette:** https://tailwindcss.com/docs/customizing-colors

---

## 💡 Tips & Best Practices

1. **Gunakan watch mode saat development** untuk auto-rebuild
2. **Build production sebelum upload** ke hosting
3. **Gunakan custom components** yang sudah dibuat (btn, card, form-input, dll)
4. **Jangan edit `output.css` langsung** - edit `input.css` lalu rebuild
5. **Gunakan custom colors** (invoice-primary, dll) untuk konsistensi
6. **Test responsive** dengan class `md:`, `lg:`, dll

---

## 🎉 Selamat!

Setup TailwindCSS sudah selesai! Sekarang Anda bisa mulai coding dengan TailwindCSS.

**Next Steps:**
1. Jalankan watch mode: `.\watch.ps1`
2. Mulai edit file PHP dengan class Tailwind
3. Lihat hasilnya di browser!

Happy coding! 🚀
